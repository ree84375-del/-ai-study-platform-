from __future__ import annotations

import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
TRAIN_PATH = ROOT / "training_data" / "eq_core_sft_train.jsonl"
VAL_PATH = ROOT / "training_data" / "eq_core_sft_val.jsonl"
REPORT_DIR = ROOT / "gate_reports"

ROBOTIC_PHRASES = [
    "我會先接住情緒，再把事情拆成可執行的一步",
    "判斷邊界：這是人際互動訓練",
    "以上就是主要的內容",
    "很高興回答你的問題",
    "若您需要更多協助",
]

FIRST_LINE_MAX_RATIO = 0.08
MIN_AVG_ASSISTANT_CHARS = 55


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            row["_file"] = str(path)
            row["_line_number"] = line_number
            rows.append(row)
    return rows


def assistant_text(record: dict[str, Any]) -> str:
    return "\n".join(
        str(message.get("content") or "")
        for message in record.get("messages", [])
        if message.get("role") == "assistant"
    ).strip()


def first_line(text: str) -> str:
    return re.split(r"[\r\n]+", text.strip(), maxsplit=1)[0].strip()


def gate() -> dict[str, Any]:
    train = load_jsonl(TRAIN_PATH)
    val = load_jsonl(VAL_PATH)
    records = train + val
    failures: list[str] = []
    issue_samples: list[dict[str, Any]] = []

    assistant_texts = [assistant_text(record) for record in records]
    first_lines = Counter(first_line(text) for text in assistant_texts if text)
    max_first_line, max_first_line_count = ("", 0)
    if first_lines:
        max_first_line, max_first_line_count = first_lines.most_common(1)[0]
    max_first_line_ratio = (max_first_line_count / len(records)) if records else 0
    avg_chars = sum(len(text) for text in assistant_texts) / len(assistant_texts) if assistant_texts else 0

    if not records:
        failures.append("dataset_missing_or_empty")
    if max_first_line_ratio > FIRST_LINE_MAX_RATIO:
        failures.append(f"first_line_template_ratio_too_high:{max_first_line_ratio:.4f}")
    if avg_chars < MIN_AVG_ASSISTANT_CHARS:
        failures.append(f"assistant_reply_average_too_short:{avg_chars:.2f}")

    for index, record in enumerate(records):
        text = assistant_text(record)
        for phrase in ROBOTIC_PHRASES:
            if phrase in text:
                issue_samples.append(
                    {
                        "index": index,
                        "file": record.get("_file"),
                        "line": record.get("_line_number"),
                        "rule": "robotic_phrase",
                        "phrase": phrase,
                        "task": record.get("metadata", {}).get("task"),
                    }
                )
                break
    if issue_samples:
        failures.append(f"robotic_phrase_count:{len(issue_samples)}")

    status = "PASS" if not failures else "FAIL"
    report = {
        "module": "KAGAMI 心鏡 EQ Core",
        "gate": "eq_human_speech_gate",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "checked_records": len(records),
        "train_records": len(train),
        "val_records": len(val),
        "max_first_line": max_first_line,
        "max_first_line_count": max_first_line_count,
        "max_first_line_ratio": round(max_first_line_ratio, 6),
        "avg_assistant_chars": round(avg_chars, 2),
        "failures": failures,
        "rules": {
            "no_repeated_template_opening": True,
            "no_robotic_boundary_phrase": True,
            "no_generic_assistant_filler": True,
            "natural_reply_must_keep_precision": True,
        },
        "issue_samples": issue_samples[:50],
    }
    REPORT_DIR.mkdir(exist_ok=True)
    report_path = REPORT_DIR / f"eq_human_speech_gate_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    report["report_path"] = str(report_path)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> int:
    report = gate()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
