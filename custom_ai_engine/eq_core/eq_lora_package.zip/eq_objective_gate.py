from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
TRAIN_PATH = ROOT / "training_data" / "eq_core_sft_train.jsonl"
VAL_PATH = ROOT / "training_data" / "eq_core_sft_val.jsonl"
REPORT_DIR = ROOT / "gate_reports"

HARD_SUBJECTIVE_PATTERNS = [
    r"我(個人)?覺得",
    r"我(個人)?認為",
    r"我(個人)?喜歡",
    r"我(個人)?討厭",
    r"我的(主觀)?看法",
    r"依我看",
]

UNSUPPORTED_CERTAINTY_PATTERNS = [
    r"百分之百",
    r"絕對(是|會|能|可以|不會|不可能)?",
    r"保證(是|會|能|可以|不會)?",
    r"一定(是|會|能|可以|不會)",
    r"肯定(是|會|能|可以|不會)",
    r"所有人都",
    r"任何人都",
]

MIND_READING_PATTERNS = [
    r"對方(一定|肯定|絕對)",
    r"他(一定|肯定|絕對)",
    r"她(一定|肯定|絕對)",
    r"真正意思(一定|肯定|就是)",
    r"代表他(一定|肯定|就是)",
    r"代表她(一定|肯定|就是)",
]

UNSUPPORTED_AUTHORITY_PATTERNS = [
    r"研究證明",
    r"科學證明",
    r"心理學證明",
    r"專家都說",
]

MANIPULATION_PATTERNS = [
    r"用.*操控",
    r"教.*操控",
    r"讓對方不得不",
    r"逼對方",
]

COPIED_SOURCE_PATTERNS = [
    r"以下是.*逐字稿",
    r"逐字稿[:：]",
    r"以下是影片內容",
    r"影片中說[:：]",
    r"字幕內容",
]

OBJECTIVE_BOUNDARY_MARKERS = [
    "資料不足",
    "不能假裝確定",
    "不能把推測當真相",
    "沒有證據",
    "不確定",
    "需要確認",
    "需要查證",
    "判斷邊界",
    "不是心理診斷",
    "不能做診斷",
    "不能替代專業診斷",
    "事實",
    "推論",
    "風險",
    "保留餘地",
    "更多上下文",
    "安全、法律、醫療或工程風險",
    "直接說不足",
]

DIAGNOSIS_BOUNDARY_MARKERS = [
    "不是心理診斷",
    "不能做診斷",
    "不能替代專業診斷",
    "找合格專業人員",
    "緊急協助",
]


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            row["_line_number"] = line_number
            row["_file"] = str(path)
            rows.append(row)
    return rows


def assistant_text(record: dict[str, Any]) -> str:
    return "\n".join(
        str(message.get("content") or "")
        for message in record.get("messages", [])
        if message.get("role") == "assistant"
    )


def user_text(record: dict[str, Any]) -> str:
    return "\n".join(
        str(message.get("content") or "")
        for message in record.get("messages", [])
        if message.get("role") == "user"
    )


def first_match(patterns: list[str], text: str) -> str | None:
    for pattern in patterns:
        if re.search(pattern, text):
            return pattern
    return None


def is_teaching_against_bad_certainty(text: str) -> bool:
    return any(
        marker in text
        for marker in [
            "少用絕對詞",
            "避免絕對",
            "不要說一定",
            "把「一定",
            "把「絕對",
            "改成「依目前",
        ]
    )


def has_boundary(text: str) -> bool:
    return any(marker in text for marker in OBJECTIVE_BOUNDARY_MARKERS)


def collect_issues(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        text = assistant_text(record)
        prompt = user_text(record)
        location = {
            "index": index,
            "file": record.get("_file"),
            "line": record.get("_line_number"),
            "source_url": record.get("metadata", {}).get("source_url"),
            "task": record.get("metadata", {}).get("task"),
        }

        checks = [
            ("subjective_opinion", HARD_SUBJECTIVE_PATTERNS),
            ("unsupported_certainty", UNSUPPORTED_CERTAINTY_PATTERNS),
            ("mind_reading_without_evidence", MIND_READING_PATTERNS),
            ("unsupported_authority_claim", UNSUPPORTED_AUTHORITY_PATTERNS),
            ("manipulation_language", MANIPULATION_PATTERNS),
            ("copied_source_text_marker", COPIED_SOURCE_PATTERNS),
        ]
        for rule_id, patterns in checks:
            matched = first_match(patterns, text)
            if rule_id == "unsupported_certainty" and matched and is_teaching_against_bad_certainty(text):
                matched = None
            if matched:
                issues.append({**location, "severity": "hard_fail", "rule": rule_id, "pattern": matched})

        if len(text.strip()) < 20:
            issues.append({**location, "severity": "hard_fail", "rule": "assistant_reply_too_short"})
        if "請用高情商方式回覆" in prompt and not has_boundary(text):
            issues.append({**location, "severity": "hard_fail", "rule": "missing_objective_boundary"})
        if "診斷" in text and not any(marker in text for marker in DIAGNOSIS_BOUNDARY_MARKERS):
            issues.append({**location, "severity": "hard_fail", "rule": "diagnosis_boundary_missing"})
    return issues


def gate() -> dict[str, Any]:
    train = load_jsonl(TRAIN_PATH)
    val = load_jsonl(VAL_PATH)
    records = train + val
    failures: list[str] = []
    if not train:
        failures.append("train_dataset_missing_or_empty")
    if not val:
        failures.append("val_dataset_missing_or_empty")

    issues = collect_issues(records)
    hard_failures = [issue for issue in issues if issue["severity"] == "hard_fail"]
    if hard_failures:
        failures.append(f"objective_hard_failures:{len(hard_failures)}")

    status = "PASS" if not failures else "FAIL"
    report = {
        "module": "KAGAMI 心鏡 EQ Core",
        "gate": "eq_objective_gate",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "train_records": len(train),
        "val_records": len(val),
        "checked_records": len(records),
        "hard_failure_count": len(hard_failures),
        "failures": failures,
        "rules": {
            "no_subjective_opinion_unless_user_asks": True,
            "no_unsupported_certainty": True,
            "no_mind_reading_as_fact": True,
            "no_fake_authority_claim": True,
            "no_copied_video_transcript_markers": True,
            "must_keep_fact_inference_risk_boundary": True,
        },
        "issue_samples": hard_failures[:50],
    }
    REPORT_DIR.mkdir(exist_ok=True)
    report_path = REPORT_DIR / f"eq_objective_gate_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    report["report_path"] = str(report_path)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> int:
    report = gate()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
