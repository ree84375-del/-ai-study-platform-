# KAGAMI 心鏡 EQ Core LoRA Package

This package contains original high-EQ interaction SFT data, source registry, and policy gates.
It does not contain copied YouTube transcripts. Run after KAGAMI BASE 7B artifact passes final gate.
