from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

BASE_MODEL_ID = os.environ.get("EQ_BASE_MODEL_ID", "Qwen/Qwen2.5-7B-Instruct")
MAX_STEPS = int(os.environ.get("EQ_MAX_STEPS", "300"))
MAX_SEQ_LENGTH = int(os.environ.get("EQ_MAX_SEQ_LENGTH", "768"))
OUTPUT_DIR = Path(os.environ.get("EQ_OUTPUT_DIR", "/kaggle/working/kagami_eq_core_lora"))
ARCHIVE_BASE = Path(os.environ.get("EQ_ARCHIVE_BASE", str(OUTPUT_DIR)))
TRAIN_PATH = Path(os.environ.get("EQ_TRAIN_PATH", "/kaggle/input/eq-lora-package/eq_core_sft_train.jsonl"))

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
os.environ.setdefault("BITSANDBYTES_NOWELCOME", "1")


def main() -> None:
    import torch
    from datasets import load_dataset
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from trl import SFTConfig, SFTTrainer

    if not torch.cuda.is_available():
        raise RuntimeError("GPU is required for EQ Core LoRA training.")

    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_ID,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
        ),
        device_map={"": 0},
        trust_remote_code=True,
    )
    model = prepare_model_for_kbit_training(model)
    model = get_peft_model(
        model,
        LoraConfig(
            r=16,
            lora_alpha=32,
            target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM",
        ),
    )
    dataset = load_dataset("json", data_files=str(TRAIN_PATH), split="train")

    def to_text(example):
        return {"text": tokenizer.apply_chat_template(example["messages"], tokenize=False, add_generation_prompt=False)}

    dataset = dataset.map(to_text, remove_columns=dataset.column_names)
    args = SFTConfig(
        output_dir=str(OUTPUT_DIR),
        per_device_train_batch_size=1,
        gradient_accumulation_steps=2,
        learning_rate=1e-4,
        max_steps=MAX_STEPS,
        logging_steps=10,
        save_steps=100,
        save_total_limit=2,
        optim="paged_adamw_8bit",
        fp16=True,
        report_to="none",
        dataset_text_field="text",
        max_seq_length=MAX_SEQ_LENGTH,
        gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": False},
    )
    trainer = SFTTrainer(model=model, train_dataset=dataset, args=args, processing_class=tokenizer)
    model.config.use_cache = False
    trainer.train()
    trainer.model.save_pretrained(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)
    (OUTPUT_DIR / "kagami_eq_core_card.json").write_text(
        json.dumps({
            "model_display_name": "KAGAMI 心鏡 EQ Core LoRA",
            "base_model_id": BASE_MODEL_ID,
            "artifact_type": "EQ domain LoRA adapter",
            "must_merge_after_base": True,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    zip_path = shutil.make_archive(str(ARCHIVE_BASE), "zip", OUTPUT_DIR)
    print("KAGAMI EQ Core LoRA saved to:", OUTPUT_DIR)
    print("Download this Kaggle output:", zip_path)


if __name__ == "__main__":
    main()
